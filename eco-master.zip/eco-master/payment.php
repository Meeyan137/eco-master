<div>
    <h2 align="center">Pay now with Paypal: </h2>
    <p align="center"> <img src="images/paypal.png" width="200" height="150"></p>
</div>
